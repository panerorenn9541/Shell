// A header file for helpers.c
// Declare any additional functions in this file
#ifndef HELPERS
#define HELPERS

#include "shell_util.h"
#include <signal.h>

int timeComparator(void *processEntry1, void *processEntry2);


void usr1(List_t bg_list);

void killBg(List_t* bg_p);

#endif
