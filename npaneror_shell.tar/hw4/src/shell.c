#include "shell_util.h"
#include "linkedList.h"
#include "helpers.h"

// Library Includes
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <sys/wait.h>

int CHLD_FLAG = 0;
int USR_FLAG = 0;

void chld_handler()
{
	CHLD_FLAG = 1;
}

void usr1_handler()
{
	USR_FLAG = 1;
}

int main(int argc, char *argv[])
{
	int i; //loop counter
	char *args[MAX_TOKENS + 1];
	int exec_result;
	int exit_status;
	int bg_proc;
	pid_t pid;
	pid_t bg_pid;
	pid_t wait_result;
    List_t bg_list;

	time_t* tp;

        List_t* bg_pt = &bg_list;
    //Initialize the linked list
    bg_list.head = NULL;
    bg_list.length = 0;
    bg_list.comparator = NULL;  // Don't forget to initialize this to your comparator!!!


	int(*func_p)(void*, void*) = timeComparator;
	bg_list.comparator = func_p;

	// Setup segmentation fault handler
	if(signal(SIGSEGV, sigsegv_handler) == SIG_ERR)
	{
		perror("Failed to set signal handler");
		exit(-1);
	}

	while(1) {
		// DO NOT MODIFY buffer
		// The buffer is dynamically allocated, we need to free it at the end of the loop
		char * const buffer = NULL;
		size_t buf_size = 0;

		// Print the shell prompt
		display_shell_prompt();
		
		// Read line from STDIN
		ssize_t nbytes = getline((char **)&buffer, &buf_size, stdin);

		// No more input from STDIN, free buffer and terminate
		if(nbytes == -1) {
			free(buffer);
			break;
		}

		// Remove newline character from buffer, if it's there
		if(buffer[nbytes - 1] == '\n')
			buffer[nbytes- 1] = '\0';

		// Handling empty strings
		if(strcmp(buffer, "") == 0) {
			free(buffer);
			continue;
		}
		
		// Parsing input string into a sequence of tokens
		size_t numTokens;
		*args = NULL;
		numTokens = tokenizer(buffer, args);

		bg_proc = 0;

		if(strcmp(args[0],"exit") == 0) {
			// Terminating the shell
			killBg(bg_pt);
			kill(-1, SIGKILL);
			free(buffer);
			return 0;
		}

		else if(strcmp(args[0], "cd") == 0)
		{
			char* cd_buffer = NULL;
			int cd_buf_size = 512;			
			
			cd_buffer = (char*) malloc(sizeof(char)*cd_buf_size);
			if(chdir(args[1]) != 0)
			{
				fprintf(stderr, DIR_ERR);
				free(buffer);
				continue;
			}
			
			while(getcwd(cd_buffer, cd_buf_size) == NULL)
			{
				cd_buf_size += 64;
				cd_buffer = (char*) realloc(cd_buffer, cd_buf_size);
			}

			fprintf(stdout, "%s\n", cd_buffer);
			free(buffer);
			continue;
		}

		else if(strcmp(args[0], "estatus") == 0)
		{
			printf("%d\n", WEXITSTATUS(exit_status));
			free(buffer);
			continue;
		}

		else if(strcmp(args[0], "fg") == 0)
		{
			if (bg_pt->length == 0)
			{
				continue;
			}
			node_t* pri = bg_pt->head;
			ProcessEntry_t* valu = pri->value;
			if (numTokens == 1)
			{
				wait_result = waitpid(valu->pid, &exit_status, 0);
				if(wait_result == -1){
                                        printf(WAIT_ERR);
                                        exit(EXIT_FAILURE);
                                }
				removeByPid(bg_pt, valu->pid);
				continue;
			}
			else if (numTokens > 1)
			{
				if(atoi(args[1]) == 0)
				{
					fprintf(stdout, "-1");
				}
				while(pri->next != NULL)
				{
					if(atoi(args[1]) == valu->pid)
					{
						wait_result = waitpid(valu->pid, &exit_status, 0);
                                		if(wait_result == -1){
                                        		printf(WAIT_ERR);
                                        		exit(EXIT_FAILURE);
                                		}
						removeByPid(bg_pt, valu->pid);
                                		break;
					}
					pri = pri->next;
					valu = pri->value;
				}

				if(atoi(args[1]) == valu->pid)
                               	{
					wait_result = waitpid(valu->pid, &exit_status, 0);
                                	if(wait_result == -1){
                                        	printf(WAIT_ERR);
                                        	exit(EXIT_FAILURE);
                                	}
					removeByPid(bg_pt, valu->pid);
					continue;
				}
				else
				{
					fprintf(stderr, PID_ERR);
					continue;
				}
			}
		
		}

		pid = fork();   //In need of error handling......
	
		if(strcmp(args[numTokens-1], "&") == 0)
		{
			time_t t;
			char* comm = NULL;
			time_t* tp = NULL;
			int allo = 0;
			tp = (time_t*) malloc(sizeof(time_t));
			t = time(tp);
		
			allo = sizeof(char)*strlen(args[0])+1;
			comm = (char*) malloc(allo);

			ProcessEntry_t* p1;

			p1 = (ProcessEntry_t*) malloc(sizeof(ProcessEntry_t));

			strcpy(comm, args[0]);
			for (i = 1; i<numTokens; i++)
			{
				allo += sizeof(char)*strlen(args[i])+1;
				comm = (char*) realloc(comm, allo);
				strcat(comm, " ");
				strcat(comm, args[i]);
			}

			p1->cmd = comm;
			p1->pid = pid;
			p1->seconds = t;

			insertInOrder(bg_pt, (void*)p1);
			
			signal(SIGCHLD, chld_handler);			

			args[numTokens-1] = NULL;
			numTokens --;

			bg_proc = 1;

		}
		
		if(CHLD_FLAG == 1)
		{
			node_t* first = bg_list.head;
			ProcessEntry_t* val = first->value;
			while ((bg_pid = waitpid(-1, NULL, WNOHANG)) > 0)
			{
				while(first->next != NULL)
				{
					if(val->pid == bg_pid)
					{
						fprintf(stdout, BG_TERM, bg_pid, val->cmd);
					}
					first = first->next;
					val = first->value;
				}
				if(val->pid == bg_pid)
				{
					fprintf(stdout, BG_TERM, bg_pid, val->cmd);
				}
				
				removeByPid(bg_pt, bg_pid);
			}
			CHLD_FLAG = 0;
		}
		
		if(pid == 0)
		{	
			if(strcmp(args[numTokens-1], "<") == 0 
				|| strcmp(args[numTokens-1], ">") == 0
					|| strcmp(args[numTokens-1], ">>") == 0
						|| strcmp(args[numTokens-1], "2>") == 0)
			{
				fprintf(stderr, RD_ERR);
				exit(EXIT_FAILURE);
			}

			if(strcmp(args[0], "<") == 0 
				|| strcmp(args[0], ">") == 0
					|| strcmp(args[0], ">>") == 0
						|| strcmp(args[0], "2>") == 0)
			{
				fprintf(stderr, RD_ERR);
				exit(EXIT_FAILURE);
			}
			
			int one = 0;
			int two = 0;
			for (i = 0; i<3; i++)
			{
				if(numTokens > 2 && strcmp(args[numTokens-2], "<") == 0)
				{
					FILE* inp = fopen(args[numTokens-1], "r");
					if (inp == NULL)
					{
						fprintf(stderr, RD_ERR);
						exit(EXIT_FAILURE);
					}
					dup2(3+i, 0);

					args[numTokens-1] = NULL;
					numTokens --;
					args[numTokens-1] = NULL;
					numTokens --;

				}

				else if(numTokens > 2 && strcmp(args[numTokens-2], ">") == 0)
				{
					if (two == 1)
					{
						fprintf(stderr, RD_ERR);
						exit(EXIT_FAILURE);
					}
					one = 1;
					FILE* outw = fopen(args[numTokens-1], "w");
					if (outw == NULL)
					{
						fprintf(stderr, RD_ERR);
						exit(EXIT_FAILURE);
					}
					dup2(3+i, 1);

					args[numTokens-1] = NULL;
					numTokens --;
					args[numTokens-1] = NULL;
					numTokens --;

				}

				else if (numTokens>2 && strcmp(args[numTokens-2], ">>") == 0)
				{
					if (one == 1)
					{
						fprintf(stderr, RD_ERR);
						exit(EXIT_FAILURE);
					}
					two = 1;
					FILE* outa = fopen(args[numTokens-1], "a");
					if (outa == NULL)
					{
						fprintf(stderr, RD_ERR);
						exit(EXIT_FAILURE);
					}
					dup2(3+i, 1);

					args[numTokens-1] = NULL;
					numTokens --;
					args[numTokens-1] = NULL;
					numTokens --;
				}

				else if (numTokens>2 && strcmp(args[numTokens-2], "2>") == 0)
				{
					FILE* oute = fopen(args[numTokens-1], "w");
					if (oute == NULL)
					{
						fprintf(stderr, RD_ERR);
						exit(EXIT_FAILURE);
					}
					dup2(3+i, 2);

					args[numTokens-1] = NULL;
					numTokens --;
					args[numTokens-1] = NULL;
					numTokens --;
				}
				else
				{
					continue;
				}
			}
		}

		if (pid == 0)
		{
			if(strcmp(args[0], "|") == 0)
			{
				fprintf(stderr, PIPE_ERR);
				exit(EXIT_FAILURE);
			}
			else if (strcmp(args[numTokens-1], "|") == 0)
			{
				fprintf(stderr, PIPE_ERR);
				exit(EXIT_FAILURE);
			}

			int num_of_pipes = 0;
			for(i = 0; i<numTokens; i++)
			{
				if(strcmp(args[i], "|") == 0)
				{
					num_of_pipes++;
					args[i] = NULL;
				}
			}
			int curr_pipe = 0;			

			if (num_of_pipes > 0)
			{
				pid_t pid2;
				int pipefd[num_of_pipes*2];
		
				for (i = 1; i<numTokens; i++)
				{
					if(args[i] == NULL)
					{
						pid_t pid2;
						if(pipe(pipefd+(curr_pipe*2)) == -1)
						{
							fprintf(stderr, PIPE_ERR);
							exit(EXIT_FAILURE);
						}
						
						curr_pipe++;
						
						args[i] = NULL;

						pid2 = fork();
						
						if(pid2 == 0)
						{
							close(pipefd[(curr_pipe-1)*2]);
							dup2(pipefd[(curr_pipe-1)*2+1], 
								(curr_pipe-1)*2+1);
							close(pipefd[(curr_pipe-1)*2+1]);
							
							exec_result = execvp(args[0], &args[0]);
							if(exec_result == -1){ //Error checking
								printf(EXEC_ERR, args[0]);
								exit(EXIT_FAILURE);
							}
							exit(EXIT_SUCCESS);
						}
						else
						{
							close(pipefd[(curr_pipe-1)*2+1]);
							dup2(pipefd[(curr_pipe-1)*2],
								(curr_pipe-1)*2);
							close(pipefd[(curr_pipe-1)*2]);
						

							if(bg_proc == 0)
							{
								wait_result = waitpid(pid2, &exit_status, 0);
							}
							else
							{
								wait_result = waitpid(pid2, &exit_status, WNOHANG);
							}
							if(wait_result == -1){
								printf(WAIT_ERR);
								exit(EXIT_FAILURE);
							}

							exec_result = execvp(args[i+1], &args[i+1]);
							if(exec_result == -1){ //Error checking
								printf(EXEC_ERR, args[0]);
								exit(EXIT_FAILURE);
							}
							exit(EXIT_SUCCESS);
						}
					}
				}
			}
		}

		if(pid != 0)
		{	
			signal(SIGUSR1, usr1_handler);
			if(USR_FLAG == 1)
			{
				usr1(bg_list);
				USR_FLAG = 0;
			}
		}		

			if (pid == 0){ //If zero, then it's the child process
				exec_result = execvp(args[0], &args[0]);
				if(exec_result == -1){ //Error checking
					printf(EXEC_ERR, args[0]);
					exit(EXIT_FAILURE);
				}
				exit(EXIT_SUCCESS);
			}
			else{ // Parent Process
				if(bg_proc == 0)
				{
					wait_result = waitpid(pid, &exit_status, 0);
				}
				else
				{
					bg_proc = 0;
					wait_result = waitpid(pid, &exit_status, WNOHANG);
				}
				if(wait_result == -1){
					printf(WAIT_ERR);
					exit(EXIT_FAILURE);
				}
			}
			continue;
			// Free the buffer allocated from getline
			free(buffer);
		}
	return 0;
}
