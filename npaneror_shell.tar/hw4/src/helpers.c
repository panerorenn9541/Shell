// Your helper functions need to be here.
#include "helpers.h"


int timeComparator(void *processEntry1, void *processEntry2)
{
	ProcessEntry_t* p1 = (ProcessEntry_t*)processEntry1;
	ProcessEntry_t* p2 = (ProcessEntry_t*)processEntry2;
	
	if (p1->seconds == p2->seconds)
	{
		return 0;
	}
	else if (p1->seconds < p2->seconds)
	{
		return -1;
	}
	else if (p1->seconds > p2->seconds)
	{
		return 1;
	}
	return 2;
	

}



void usr1(List_t bg_list)
{
	int i = 0;
	
	if(bg_list.length > 0)
	{
		node_t* fir = bg_list.head;
		ProcessEntry_t* val = fir->value;
	
		while(fir->next != NULL)
		{
			printBGPEntry(val);		

			fir = fir->next;
			val = fir->value;
		}
	
		printBGPEntry(val);
	}
}

void killBg(List_t* bg_p)
{
	if(bg_p->length > 0)
	{
		node_t*	ne = bg_p->head;
		ProcessEntry_t* va = ne->value;
	
		while(ne->next != NULL)
		{
			fprintf(stdout, BG_TERM, va->pid, va->cmd);
			kill(va->pid, SIGKILL);
			ne = ne->next;
			va = ne->value;
		}
		
		fprintf(stdout, BG_TERM, va->pid, va->cmd);
	}
}


